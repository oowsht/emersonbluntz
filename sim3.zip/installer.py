import os
import sys


os.system('sudo apt update -y')
os.system('apt install git -y')
os.system('sudo apt install nodejs -y')
os.system('sudo apt install npm -y')
os.system('sudo npm install cloudflare-bypasser -y')
os.system('sudo npm install crypto-random-string -y')
os.system('sudo npm install random-string -y')
os.system('sudo npm install random-useragent -y')
os.system('sudo npm install fs -y')
os.system('sudo npm install url -y')
os.system('sudo npm install net -y')
os.system('sudo npm install eval -y')
os.system('sudo npm install cloudscraper -y')
os.system('npm install')
os.system('sudo apt install python3 -y')
os.system('sudo apt install python3-pip -y')
os.system('sudo pip3 install -r requirements.txt -y')
os.system('sudo apt install python-minimal -y')
os.system('sudo apt install perl -y')
os.system('chmod +x darkness')
os.system('sudo ./darkness')


